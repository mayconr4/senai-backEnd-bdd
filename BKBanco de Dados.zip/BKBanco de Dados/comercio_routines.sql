-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: comercio
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `vw_produtos_categorias`
--

DROP TABLE IF EXISTS `vw_produtos_categorias`;
/*!50001 DROP VIEW IF EXISTS `vw_produtos_categorias`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_produtos_categorias` AS SELECT 
 1 AS `id_produto`,
 1 AS `nome_produto`,
 1 AS `marca`,
 1 AS `valor_venda`,
 1 AS `nome_categoria`,
 1 AS `descricao_categoria`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `produto_preco`
--

DROP TABLE IF EXISTS `produto_preco`;
/*!50001 DROP VIEW IF EXISTS `produto_preco`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `produto_preco` AS SELECT 
 1 AS `id_produto`,
 1 AS `nome_produto`,
 1 AS `marca`,
 1 AS `valor_venda`,
 1 AS `nome_categoria`,
 1 AS `descricao_categoria`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_produtos_categoria`
--

DROP TABLE IF EXISTS `vw_produtos_categoria`;
/*!50001 DROP VIEW IF EXISTS `vw_produtos_categoria`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_produtos_categoria` AS SELECT 
 1 AS `id_produto`,
 1 AS `nome_produto`,
 1 AS `marca`,
 1 AS `valor_venda`,
 1 AS `nome_categoria`,
 1 AS `descricao_categoria`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vw_produtos_categorias`
--

/*!50001 DROP VIEW IF EXISTS `vw_produtos_categorias`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_produtos_categorias` AS select `p`.`id_produto` AS `id_produto`,`p`.`nome_produto` AS `nome_produto`,`p`.`marca` AS `marca`,`p`.`valor_venda` AS `valor_venda`,`c`.`nome_categoria` AS `nome_categoria`,`c`.`descricao` AS `descricao_categoria` from (`produto` `p` join `categoria` `c` on((`p`.`id_categoria` = `c`.`id_categoria`))) where ((`p`.`ativo` = true) and (`c`.`ativa` = true)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `produto_preco`
--

/*!50001 DROP VIEW IF EXISTS `produto_preco`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `produto_preco` AS select `p`.`id_produto` AS `id_produto`,`p`.`nome_produto` AS `nome_produto`,`p`.`marca` AS `marca`,`p`.`valor_venda` AS `valor_venda`,`c`.`nome_categoria` AS `nome_categoria`,`c`.`descricao` AS `descricao_categoria` from (`produto` `p` join `categoria` `c` on((`p`.`id_categoria` = `c`.`id_categoria`))) where ((`p`.`ativo` = true) and (`c`.`ativa` = true)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_produtos_categoria`
--

/*!50001 DROP VIEW IF EXISTS `vw_produtos_categoria`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_produtos_categoria` AS select `p`.`id_produto` AS `id_produto`,`p`.`nome_produto` AS `nome_produto`,`p`.`marca` AS `marca`,`p`.`valor_venda` AS `valor_venda`,`c`.`nome_categoria` AS `nome_categoria`,`c`.`descricao` AS `descricao_categoria` from (`produto` `p` join `categoria` `c` on((`p`.`id_categoria` = `c`.`id_categoria`))) where ((`p`.`ativo` = true) and (`c`.`ativa` = true)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-29 18:36:44
